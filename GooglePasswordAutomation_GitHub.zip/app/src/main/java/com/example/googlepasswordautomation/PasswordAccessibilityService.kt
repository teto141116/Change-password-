package com.example.googlepasswordautomation

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class PasswordAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var stage = Stage.SEARCH
    private var lastWindowSignature = ""
    private var retryCount = 0

    private enum class Stage { SEARCH, NEW_PASSWORD, CONFIRM_PASSWORD, SUBMIT, DONE }

    override fun onServiceConnected() {
        super.onServiceConnected()
        stage = Stage.SEARCH
        retryCount = 0
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (!MainActivity.automationEnabled) return
        if (event == null) return

        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ processSafely() }, 250)
    }

    private fun processSafely() {
        try {
            process()
        } catch (_: Throwable) {
            // Never let a malformed browser accessibility tree kill the service.
            retryCount++
            if (retryCount < 10) {
                handler.postDelayed({ processSafely() }, 800)
            }
        }
    }

    private fun process() {
        if (!MainActivity.automationEnabled || stage == Stage.DONE) return
        val root = rootInActiveWindow ?: return

        val signature = windowSignature(root)
        if (signature != lastWindowSignature) {
            lastWindowSignature = signature
            retryCount = 0
        }

        // Browser-independent: no package whitelist. We work with the active window's
        // accessibility tree, regardless of whether it is Chrome, Firefox, Edge, Brave, etc.
        when (stage) {
            Stage.SEARCH -> {
                // We intentionally do not click arbitrary "Password" links until the
                // active tree contains a password-related navigation target.
                if (clickByMeaning(root, NAVIGATION_TERMS)) {
                    stage = Stage.NEW_PASSWORD
                    scheduleRetry()
                }
            }

            Stage.NEW_PASSWORD -> {
                val fields = editableFields(root)
                val newField = fields.firstOrNull { semanticText(it).matchesAny(NEW_TERMS) }
                    ?: fields.firstOrNull { isPasswordInput(it) }

                if (newField != null && setSecret(newField)) {
                    stage = Stage.CONFIRM_PASSWORD
                    scheduleRetry()
                }
            }

            Stage.CONFIRM_PASSWORD -> {
                val fields = editableFields(root)
                val confirmField = fields.firstOrNull { semanticText(it).matchesAny(CONFIRM_TERMS) }
                    ?: fields.firstOrNull { isPasswordInput(it) && it != fields.firstOrNull() }

                if (confirmField != null && setSecret(confirmField)) {
                    stage = Stage.SUBMIT
                    scheduleRetry()
                }
            }

            Stage.SUBMIT -> {
                // Submit only when a clear save/change-password action is exposed.
                if (clickByMeaning(root, SAVE_TERMS)) {
                    stage = Stage.DONE
                    clearSecret()
                }
            }

            Stage.DONE -> Unit
        }
    }

    private fun scheduleRetry() {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ processSafely() }, 700)
    }

    private fun clickByMeaning(root: AccessibilityNodeInfo, terms: Set<String>): Boolean {
        if (!rateLimit()) return false
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectNodes(root, candidates)

        // Prefer exact/near-exact semantic labels over generic text.
        for (node in candidates) {
            if (!node.isVisibleToUser || !node.isEnabled) continue
            val s = semanticText(node)
            if (s.isNotEmpty() && s.matchesAny(terms)) {
                if (clickNodeOrParent(node)) return true
            }
        }
        return false
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return true
        }
        var parent = node.parent
        repeat(5) {
            if (parent != null) {
                if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
                parent = parent.parent
            }
        }
        return false
    }

    private fun editableFields(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val all = mutableListOf<AccessibilityNodeInfo>()
        collectNodes(root, all)
        return all.filter { it.isVisibleToUser && it.isEnabled && it.isEditable }
    }

    private fun isPasswordInput(node: AccessibilityNodeInfo): Boolean {
        val cls = node.className?.toString()?.lowercase(Locale.ROOT) ?: ""
        val s = semanticText(node)
        return cls.contains("edittext") &&
            (s.containsAny(PASSWORD_TERMS) || node.inputType and 0xF == 0x1)
    }

    private fun setSecret(node: AccessibilityNodeInfo): Boolean {
        val secret = MainActivity.pendingPassword ?: return false
        if (secret.isEmpty()) return false

        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                String(secret)
            )
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        out.add(node)
        for (i in 0 until node.childCount) {
            collectNodes(node.getChild(i), out)
        }
    }

    private fun semanticText(node: AccessibilityNodeInfo): String {
        val parts = listOf(
            node.text?.toString(),
            node.hintText?.toString(),
            node.contentDescription?.toString(),
            node.viewIdResourceName?.substringAfterLast("/")
        )
        return parts.filter { !it.isNullOrBlank() }
            .joinToString(" ")
            .lowercase(Locale.ROOT)
            .trim()
    }

    private fun windowSignature(root: AccessibilityNodeInfo): String {
        val list = mutableListOf<AccessibilityNodeInfo>()
        collectNodes(root, list)
        return list.take(40).joinToString("|") { semanticText(it) }
    }

    private fun rateLimit(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 1000) return false
        lastActionAt = now
        return true
    }

    private fun clearSecret() {
        MainActivity.pendingPassword?.fill('\u0000')
        MainActivity.pendingPassword = null
        MainActivity.automationEnabled = false
    }

    override fun onInterrupt() {
        clearSecret()
        handler.removeCallbacksAndMessages(null)
    }

    companion object {
        private val PASSWORD_TERMS = setOf(
            "password", "passcode", "passwd", "passwort", "mot de passe",
            "contraseña", "senha", "пароль", "كلمة المرور", "كلمه المرور",
            "пароль", "암호", "비밀번호", "密码", "密碼", "パスワード"
        )

        private val NAVIGATION_TERMS = setOf(
            "password", "passwords", "passcode", "passwd", "passwort",
            "mot de passe", "contraseña", "senha", "пароль",
            "كلمة المرور", "كلمات المرور", "مدير كلمات المرور",
            "password manager", "password manager", "login and security",
            "security", "seguridad", "sécurité", "sicherheit", "segurança",
            "segurança e privacidade", "비밀번호", "암호", "密码", "密碼",
            "パスワード"
        )

        private val NEW_TERMS = setOf(
            "new password", "new passcode", "nouveau mot de passe",
            "nuevo password", "nueva contraseña", "neues passwort",
            "nova senha", "новый пароль", "كلمة المرور الجديدة",
            "كلمة مرور جديدة", "新しいパスワード", "新密码", "新密碼",
            "새 비밀번호"
        )

        private val CONFIRM_TERMS = setOf(
            "confirm password", "confirm new password", "re-enter password",
            "repeat password", "confirmer le mot de passe", "confirmar contraseña",
            "passwort bestätigen", "confirmar senha", "подтвердите пароль",
            "تأكيد كلمة المرور", "تأكيد كلمة المرور الجديدة", "أعد إدخال كلمة المرور",
            "パスワードを確認", "确认密码", "確認密碼", "비밀번호 확인"
        )

        private val SAVE_TERMS = setOf(
            "save", "save password", "change password", "update password",
            "change", "continue", "done", "enregistrer", "modifier",
            "guardar", "cambiar contraseña", "speichern", "kennwort ändern",
            "salvar", "alterar senha", "изменить пароль", "сохранить",
            "تغيير كلمة المرور", "تغيير كلمة السر", "حفظ", "حفظ التغييرات",
            "متابعة", "تم", "パスワードを変更", "保存", "変更",
            "更改密码", "保存更改", "비밀번호 변경"
        )

        private fun String.matchesAny(set: Set<String>): Boolean {
            val x = this.lowercase(Locale.ROOT)
            return set.any { t -> x == t || x.contains(t) }
        }

        private fun String.containsAny(set: Set<String>): Boolean =
            set.any { contains(it, ignoreCase = true) }
    }
}
