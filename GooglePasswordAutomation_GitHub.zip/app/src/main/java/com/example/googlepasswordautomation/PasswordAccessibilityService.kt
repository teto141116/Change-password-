package com.example.googlepasswordautomation

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PasswordAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var stage = Stage.FIND_PASSWORD_PAGE

    private enum class Stage {
        FIND_PASSWORD_PAGE,
        FILL_NEW_PASSWORD,
        FILL_CONFIRMATION,
        SUBMIT,
        DONE
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!MainActivity.automationEnabled) return
        if (event?.packageName?.toString() != "com.android.chrome") return

        // Give Chrome a moment to finish rendering its current page.
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ process() }, 450)
    }

    private fun process() {
        if (!MainActivity.automationEnabled || stage == Stage.DONE) return
        val root = rootInActiveWindow ?: return

        // Never inspect password values. We only locate fields/buttons.
        when (stage) {
            Stage.FIND_PASSWORD_PAGE -> {
                if (clickFirst(
                        root,
                        listOf("Password", "كلمة المرور", "Passwort", "Mot de passe")
                    )) {
                    stage = Stage.FILL_NEW_PASSWORD
                }
            }

            Stage.FILL_NEW_PASSWORD -> {
                val fields = findEditableNodes(root)
                val target = fields.firstOrNull { looksLikeNewPassword(it) }
                    ?: fields.firstOrNull()
                if (target != null && setText(target, MainActivity.pendingPassword)) {
                    stage = Stage.FILL_CONFIRMATION
                }
            }

            Stage.FILL_CONFIRMATION -> {
                val fields = findEditableNodes(root)
                val target = fields.drop(1).firstOrNull()
                    ?: fields.firstOrNull { looksLikeConfirmation(it) }
                if (target != null && setText(target, MainActivity.pendingPassword)) {
                    stage = Stage.SUBMIT
                }
            }

            Stage.SUBMIT -> {
                // Do not bypass CAPTCHA, 2-step verification, recovery or security prompts.
                val clicked = clickFirst(
                    root,
                    listOf("Change password", "Save", "حفظ", "تغيير كلمة المرور")
                )
                if (clicked) {
                    stage = Stage.DONE
                    clearSecret()
                }
            }

            Stage.DONE -> Unit
        }
    }

    private fun clickFirst(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 1200) return false

        for (label in labels) {
            val nodes = root.findAccessibilityNodeInfosByText(label)
            for (node in nodes) {
                if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    lastActionAt = now
                    return true
                }
                var p = node.parent
                while (p != null) {
                    if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        lastActionAt = now
                        return true
                    }
                    p = p.parent
                }
            }
        }
        return false
    }

    private fun findEditableNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        walk(root, out)
        return out.filter { it.isEditable && it.isEnabled }
    }

    private fun walk(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable) out.add(node)
        for (i in 0 until node.childCount) walk(node.getChild(i), out)
    }

    private fun looksLikeNewPassword(node: AccessibilityNodeInfo): Boolean {
        val s = ((node.hintText ?: "").toString() + " " + (node.text ?: "").toString()).lowercase()
        return s.contains("new password") || s.contains("كلمة المرور الجديدة")
    }

    private fun looksLikeConfirmation(node: AccessibilityNodeInfo): Boolean {
        val s = ((node.hintText ?: "").toString() + " " + (node.text ?: "").toString()).lowercase()
        return s.contains("confirm") || s.contains("تأكيد")
    }

    private fun setText(node: AccessibilityNodeInfo, secret: CharArray?): Boolean {
        if (secret == null || secret.isEmpty()) return false
        val b = android.os.Bundle()
        b.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            String(secret)
        )
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        return ok
    }

    private fun clearSecret() {
        MainActivity.pendingPassword?.fill('\u0000')
        MainActivity.pendingPassword = null
        MainActivity.automationEnabled = false
    }

    override fun onInterrupt() {
        clearSecret()
    }
}
