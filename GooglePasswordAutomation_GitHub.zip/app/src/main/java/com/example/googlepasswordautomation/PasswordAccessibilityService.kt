package com.example.googlepasswordautomation

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PasswordAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L
    private var loopScheduled = false
    private var serviceConnected = false

    private enum class Stage { FIND_PASSWORD, VERIFY_CURRENT, FILL_NEW, FILL_CONFIRM, SUBMIT, DONE }
    private var stage = Stage.FIND_PASSWORD
    private var scrollAttempts = 0
    private var observedRunId = -1L

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceConnected = true
        MainActivity.serviceConnected = true
        MainActivity.serviceStatus = "Accessibility متصلة ✓"
        observedRunId = -1L
        scheduleLoop(100)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!MainActivity.automationEnabled) return
        MainActivity.lastPackage = event?.packageName?.toString() ?: ""
        MainActivity.eventCount++
        // Do NOT cancel the repeating loop here. Previous versions cancelled
        // the loop whenever a browser event arrived, which could make the app
        // appear completely inactive.
        scheduleLoop(80)
    }

    private fun scheduleLoop(delay: Long) {
        if (loopScheduled || !serviceConnected) return
        loopScheduled = true
        handler.postDelayed({
            loopScheduled = false
            runAutomation()
            if (serviceConnected) scheduleLoop(500)
        }, delay)
    }

    private fun runAutomation() {
        if (!MainActivity.automationEnabled) {
            MainActivity.serviceStatus = if (serviceConnected) "Accessibility متصلة ✓ — في انتظار ON" else "Accessibility غير متصلة"
            return
        }

        if (observedRunId != MainActivity.automationRunId) {
            observedRunId = MainActivity.automationRunId
            stage = Stage.FIND_PASSWORD
            scrollAttempts = 0
            lastActionAt = 0L
            MainActivity.serviceStatus = "بدأ التنفيذ — جاري فحص الشاشة…"
        }

        val root = rootInActiveWindow
        if (root == null) {
            MainActivity.serviceStatus = "الخدمة متصلة ✓ لكن لا توجد نافذة قابلة للقراءة حاليًا"
            return
        }

        MainActivity.lastPackage = root.packageName?.toString() ?: MainActivity.lastPackage
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        MainActivity.lastNodeCount = nodes.size

        when (stage) {
            Stage.FIND_PASSWORD -> {
                if (isGoogleAccountPage(nodes)) {
                    MainActivity.serviceStatus = "تم اكتشاف صفحة Google Account ✓ — جاري البحث عن Google Password…"
                    if (clickByText(root, listOf(
                            "Google password", "Google Password",
                            "كلمة مرور Google", "كلمة المرور",
                            "Mot de passe", "Contraseña", "Passwort",
                            "Пароль", "密码"
                        ))) {
                        stage = Stage.VERIFY_CURRENT
                        scrollAttempts = 0
                        MainActivity.serviceStatus = "تم فتح Google Password ✓"
                    } else if (scrollGoogleAccountPage(root)) {
                        MainActivity.serviceStatus = "Google Password غير ظاهر — جاري التمرير والبحث…"
                    } else {
                        MainActivity.serviceStatus = "صفحة Google Account موجودة، لكن المتصفح لم يعرض زر Google Password في Accessibility tree"
                    }
                } else {
                    MainActivity.serviceStatus = "Accessibility متصلة ✓ — الصفحة الحالية ليست Google Account"
                }
            }

            Stage.VERIFY_CURRENT -> {
                val fields = editableNodes(root)
                val current = MainActivity.currentPassword
                val verification = fields.firstOrNull {
                    descriptor(it).containsAny(
                        "enter your password", "password", "كلمة المرور", "mot de passe",
                        "contraseña", "passwort", "пароль", "密码"
                    ) && !descriptor(it).containsAny(
                        "new password", "confirm new password", "تأكيد", "confirm"
                    )
                }
                if (verification != null && current != null && current.isNotEmpty()) {
                    if (setText(verification, current)) {
                        MainActivity.serviceStatus = "تم إدخال كلمة المرور الحالية ✓"
                        clickByText(root, listOf("Next", "التالي", "Suivant", "Weiter", "Siguiente", "Далее", "下一步"))
                        stage = Stage.FILL_NEW
                    }
                    return
                }
                if (fields.any { descriptor(it).containsAny("new password", "كلمة المرور الجديدة", "nouveau mot de passe", "neues passwort", "nueva contraseña", "новый пароль", "新密码") }) {
                    stage = Stage.FILL_NEW
                } else {
                    MainActivity.serviceStatus = "تم فتح صفحة Password — في انتظار خانة التحقق أو صفحة كلمة المرور الجديدة…"
                }
            }

            Stage.FILL_NEW -> {
                val fields = editableNodes(root)
                val target = fields.firstOrNull {
                    descriptor(it).containsAny("new password", "كلمة المرور الجديدة", "nouveau mot de passe", "neues passwort", "nueva contraseña", "новый пароль", "新密码")
                } ?: fields.firstOrNull()
                if (target != null && setText(target, MainActivity.newPassword)) {
                    stage = Stage.FILL_CONFIRM
                    MainActivity.serviceStatus = "تم إدخال كلمة المرور الجديدة ✓"
                }
            }

            Stage.FILL_CONFIRM -> {
                val fields = editableNodes(root)
                val target = fields.firstOrNull {
                    descriptor(it).containsAny("confirm new password", "confirm password", "تأكيد كلمة المرور", "confirmer", "bestätigen", "confirmar", "подтверд", "确认")
                } ?: fields.drop(1).firstOrNull()
                if (target != null && setText(target, MainActivity.newPassword)) {
                    stage = Stage.SUBMIT
                    MainActivity.serviceStatus = "تم تأكيد كلمة المرور ✓ — جاري البحث عن Change password…"
                }
            }

            Stage.SUBMIT -> {
                if (clickByText(root, listOf(
                        "Change password", "Save", "حفظ", "تغيير كلمة المرور",
                        "Changer le mot de passe", "Passwort ändern", "Cambiar contraseña",
                        "Изменить пароль", "更改密码"
                    ))) {
                    stage = Stage.DONE
                    MainActivity.serviceStatus = "تم الضغط على Change password ✓"
                    clearSecrets()
                }
            }
            Stage.DONE -> MainActivity.serviceStatus = "انتهى التنفيذ ✓"
        }
    }

    private fun isGoogleAccountPage(nodes: List<AccessibilityNodeInfo>): Boolean {
        val pageText = nodes.asSequence().map { descriptor(it) }.filter { it.isNotBlank() }.joinToString(" ")
        return pageText.containsAny(
            "Google Account", "Google accounts", "حساب Google", "Compte Google", "Cuenta de Google", "Google-Konto", "Аккаунт Google", "Google アカウント",
            "Personal info", "Security and sign-in", "Wallet and subscriptions", "Personal information", "المعلومات الشخصية", "الأمان وتسجيل الدخول", "Google password", "Password Manager"
        )
    }

    private fun scrollGoogleAccountPage(root: AccessibilityNodeInfo): Boolean {
        if (scrollAttempts >= 20) return false
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        for (node in nodes) {
            if (node.isScrollable && node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
                scrollAttempts++
                return true
            }
        }
        return false
    }

    private fun descriptor(node: AccessibilityNodeInfo): String = listOf(node.text, node.hintText, node.contentDescription, node.tooltipText).joinToString(" ").lowercase()
    private fun String.containsAny(vararg values: String): Boolean = values.any { contains(it.lowercase()) }

    private fun editableNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>(); collectEditable(root, out); return out.filter { it.isEditable && it.isEnabled }
    }
    private fun collectEditable(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable) out.add(node)
        for (i in 0 until node.childCount) collectEditable(node.getChild(i), out)
    }
    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        out.add(node)
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun clickByText(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 900) return false
        val wanted = labels.map { it.lowercase() }
        val nodes = mutableListOf<AccessibilityNodeInfo>(); collect(root, nodes)
        for (node in nodes) {
            val d = descriptor(node)
            if (wanted.any { d.contains(it) }) {
                var p: AccessibilityNodeInfo? = node
                repeat(6) {
                    if (p?.isClickable == true && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        lastActionAt = now; return true
                    }
                    p = p?.parent
                }
            }
        }
        return false
    }

    private fun setText(node: AccessibilityNodeInfo, value: CharArray?): Boolean {
        if (value == null || value.isEmpty()) return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, String(value)) }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun clearSecrets() {
        MainActivity.currentPassword?.fill('\u0000')
        MainActivity.newPassword?.fill('\u0000')
        MainActivity.currentPassword = null
        MainActivity.newPassword = null
        MainActivity.automationEnabled = false
    }

    override fun onInterrupt() {
        serviceConnected = false
        MainActivity.serviceConnected = false
        MainActivity.serviceStatus = "Accessibility انقطعت"
        handler.removeCallbacksAndMessages(null)
        loopScheduled = false
        clearSecrets()
    }
}
