package com.example.googlepasswordautomation

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PasswordAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L

    private enum class Stage { FIND_PASSWORD, VERIFY_CURRENT, FILL_NEW, FILL_CONFIRM, SUBMIT, DONE }
    private var stage = Stage.FIND_PASSWORD
    private var scrollAttempts = 0
    private var seenRunId = -1L
    private var lastPackage = ""
    private val poll = object : Runnable {
        override fun run() {
            if (MainActivity.automationEnabled) runAutomation()
            handler.postDelayed(this, 500)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(poll)
        handler.post(poll)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!MainActivity.automationEnabled) return
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed(poll, 250)
    }

    private fun runAutomation() {
        if (!MainActivity.automationEnabled) return

        if (seenRunId != MainActivity.automationRunId) {
            seenRunId = MainActivity.automationRunId
            stage = Stage.FIND_PASSWORD
            scrollAttempts = 0
            lastActionAt = 0L
        }

        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString().orEmpty()
        lastPackage = pkg

        // Never automate our own UI. Wait for the active browser/Google page.
        if (pkg == packageName) return

        when (stage) {
            Stage.FIND_PASSWORD -> {
                // As soon as the Google Account page is visible, search its
                // accessibility tree. If Google Password is below the fold,
                // scroll the page and keep searching until it is exposed.
                if (isGoogleAccountPage(root)) {
                    if (clickByText(root, listOf(
                            "Google password", "Google Password",
                            "Google password manager",
                            "كلمة مرور Google", "كلمة المرور",
                            "Mot de passe Google", "Mot de passe",
                            "Contraseña de Google", "Contraseña",
                            "Google-Passwort", "Passwort",
                            "Пароль Google", "Пароль", "Google 密码", "密码"
                        ))) {
                        stage = Stage.VERIFY_CURRENT
                        scrollAttempts = 0
                    } else {
                        scrollGoogleAccountPage(root)
                    }
                }
            }
            Stage.VERIFY_CURRENT -> {
                val fields = editableNodes(root)
                val current = MainActivity.currentPassword
                val verification = fields.firstOrNull {
                    descriptor(it).containsAny(
                        "enter your password", "password", "كلمة المرور", "mot de passe",
                        "contraseña", "passwort", "пароль", "密码"
                    ) && !descriptor(it).containsAny(
                        "new password", "confirm new password", "تأكيد", "confirm"
                    )
                }
                if (verification != null && current != null && current.isNotEmpty()) {
                    if (setText(verification, current)) {
                        stage = Stage.FILL_NEW
                        clickByText(root, listOf("Next", "التالي", "Suivant", "Weiter", "Siguiente", "Далее", "下一步"))
                    }
                    return
                }
                if (fields.any { descriptor(it).containsAny("new password", "كلمة المرور الجديدة", "nouveau mot de passe", "neues passwort", "nueva contraseña", "новый пароль", "新密码") }) {
                    stage = Stage.FILL_NEW
                }
            }
            Stage.FILL_NEW -> {
                val target = editableNodes(root).firstOrNull {
                    descriptor(it).containsAny("new password", "كلمة المرور الجديدة", "nouveau mot de passe", "neues passwort", "nueva contraseña", "новый пароль", "新密码")
                } ?: editableNodes(root).firstOrNull()
                if (target != null && setText(target, MainActivity.newPassword)) stage = Stage.FILL_CONFIRM
            }
            Stage.FILL_CONFIRM -> {
                val fields = editableNodes(root)
                val target = fields.firstOrNull {
                    descriptor(it).containsAny("confirm new password", "confirm password", "تأكيد كلمة المرور", "confirmer", "bestätigen", "confirmar", "подтверд", "确认")
                } ?: fields.drop(1).firstOrNull()
                if (target != null && setText(target, MainActivity.newPassword)) stage = Stage.SUBMIT
            }
            Stage.SUBMIT -> {
                if (clickByText(root, listOf(
                        "Change password", "Save", "حفظ", "تغيير كلمة المرور",
                        "Changer le mot de passe", "Passwort ändern", "Cambiar contraseña",
                        "Изменить пароль", "更改密码"
                    ))) {
                    stage = Stage.DONE
                    clearSecrets()
                }
            }
            Stage.DONE -> Unit
        }
    }

    private fun isGoogleAccountPage(root: AccessibilityNodeInfo): Boolean {
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        val allText = nodes.asSequence()
            .map { descriptor(it) }
            .filter { it.isNotBlank() }
            .joinToString(" | ")

        val account = allText.containsAny(
            "google account", "google accounts", "حساب google",
            "compte google", "cuenta de google", "google-konto",
            "аккаунт google", "google アカウント"
        )
        val accountSections = allText.containsAny(
            "personal info", "security and sign-in", "security & sign-in",
            "google password", "personal information",
            "المعلومات الشخصية", "الأمان وتسجيل الدخول", "كلمة مرور google"
        )
        return account || accountSections
    }

    private fun scrollGoogleAccountPage(root: AccessibilityNodeInfo) {
        if (scrollAttempts >= 30) return

        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)

        for (node in nodes) {
            if (node.isScrollable &&
                node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            ) {
                scrollAttempts++
                return
            }
        }
    }

    private fun descriptor(node: AccessibilityNodeInfo): String =
        listOf(
            node.text,
            node.hintText,
            node.contentDescription,
            node.viewIdResourceName
        ).filterNotNull().joinToString(" ").replace("\u00a0", " ").trim().lowercase()

    private fun String.containsAny(vararg values: String): Boolean = values.any { contains(it.lowercase()) }

    private fun editableNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        walk(root, out)
        return out.filter { it.isEditable && it.isEnabled }
    }

    private fun walk(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable) out.add(node)
        for (i in 0 until node.childCount) walk(node.getChild(i), out)
    }

    private fun clickByText(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 900) return false
        val wanted = labels.map { it.lowercase() }
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        for (node in nodes) {
            if (wanted.any { descriptor(node).contains(it) }) {
                var p: AccessibilityNodeInfo? = node
                repeat(4) {
                    if (p?.isClickable == true && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        lastActionAt = now
                        return true
                    }
                    p = p?.parent
                }
            }
        }
        return false
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        out.add(node)
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun setText(node: AccessibilityNodeInfo, value: CharArray?): Boolean {
        if (value == null || value.isEmpty()) return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, String(value))
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun clearSecrets() {
        MainActivity.currentPassword?.fill('\u0000')
        MainActivity.newPassword?.fill('\u0000')
        MainActivity.currentPassword = null
        MainActivity.newPassword = null
        MainActivity.automationEnabled = false
    }

    override fun onInterrupt() { clearSecrets() }
}
