package com.example.googlepasswordautomation

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PasswordAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastActionAt = 0L

    private enum class Stage { FIND_PASSWORD, VERIFY_CURRENT, FILL_NEW, FILL_CONFIRM, SUBMIT, DONE }
    private var stage = Stage.FIND_PASSWORD
    private var scrollAttempts = 0
    private var observedRunId = -1L
    private var serviceConnected = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceConnected = true
        scheduleLoop(200)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!MainActivity.automationEnabled) return
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ runAutomation() }, 120)
    }

    private fun scheduleLoop(delay: Long = 700) {
        handler.postDelayed({
            runAutomation()
            if (serviceConnected) scheduleLoop(700)
        }, delay)
    }

    private fun runAutomation() {
        if (!MainActivity.automationEnabled) return

        // Every press of "Start" begins a fresh state machine, even if the
        // accessibility service was already running or had reached DONE.
        if (observedRunId != MainActivity.automationRunId) {
            observedRunId = MainActivity.automationRunId
            stage = Stage.FIND_PASSWORD
            scrollAttempts = 0
            lastActionAt = 0L
        }

        val root = rootInActiveWindow ?: return

        when (stage) {
            Stage.FIND_PASSWORD -> {
                // As soon as the Google Account page is visible, search its
                // accessibility tree. If Google Password is below the fold,
                // scroll the page and keep searching until it is exposed.
                if (isGoogleAccountPage(root)) {
                    if (clickByText(root, listOf(
                            "Google password", "Google Password",
                            "كلمة مرور Google", "كلمة المرور",
                            "Mot de passe", "Contraseña", "Passwort",
                            "Пароль", "密码"
                        ))) {
                        stage = Stage.VERIFY_CURRENT
                        scrollAttempts = 0
                    } else {
                        scrollGoogleAccountPage(root)
                    }
                }
            }
            Stage.VERIFY_CURRENT -> {
                val fields = editableNodes(root)
                val current = MainActivity.currentPassword
                val verification = fields.firstOrNull {
                    descriptor(it).containsAny(
                        "enter your password", "password", "كلمة المرور", "mot de passe",
                        "contraseña", "passwort", "пароль", "密码"
                    ) && !descriptor(it).containsAny(
                        "new password", "confirm new password", "تأكيد", "confirm"
                    )
                }
                if (verification != null && current != null && current.isNotEmpty()) {
                    if (setText(verification, current)) {
                        stage = Stage.FILL_NEW
                        clickByText(root, listOf("Next", "التالي", "Suivant", "Weiter", "Siguiente", "Далее", "下一步"))
                    }
                    return
                }
                if (fields.any { descriptor(it).containsAny("new password", "كلمة المرور الجديدة", "nouveau mot de passe", "neues passwort", "nueva contraseña", "новый пароль", "新密码") }) {
                    stage = Stage.FILL_NEW
                }
            }
            Stage.FILL_NEW -> {
                val target = editableNodes(root).firstOrNull {
                    descriptor(it).containsAny("new password", "كلمة المرور الجديدة", "nouveau mot de passe", "neues passwort", "nueva contraseña", "новый пароль", "新密码")
                } ?: editableNodes(root).firstOrNull()
                if (target != null && setText(target, MainActivity.newPassword)) stage = Stage.FILL_CONFIRM
            }
            Stage.FILL_CONFIRM -> {
                val fields = editableNodes(root)
                val target = fields.firstOrNull {
                    descriptor(it).containsAny("confirm new password", "confirm password", "تأكيد كلمة المرور", "confirmer", "bestätigen", "confirmar", "подтверд", "确认")
                } ?: fields.drop(1).firstOrNull()
                if (target != null && setText(target, MainActivity.newPassword)) stage = Stage.SUBMIT
            }
            Stage.SUBMIT -> {
                if (clickByText(root, listOf(
                        "Change password", "Save", "حفظ", "تغيير كلمة المرور",
                        "Changer le mot de passe", "Passwort ändern", "Cambiar contraseña",
                        "Изменить пароль", "更改密码"
                    ))) {
                    stage = Stage.DONE
                    clearSecrets()
                }
            }
            Stage.DONE -> Unit
        }
    }

    private fun isGoogleAccountPage(root: AccessibilityNodeInfo): Boolean {
        // The root node itself often has no text. Search the COMPLETE
        // accessibility tree, including descendants, instead of checking
        // only descriptor(root).
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        val pageText = nodes.asSequence()
            .map { descriptor(it) }
            .filter { it.isNotBlank() }
            .joinToString(" ")

        val hasGoogleAccount = pageText.containsAny(
            "Google Account", "Google accounts", "حساب Google",
            "Compte Google", "Cuenta de Google", "Google-Konto",
            "Аккаунт Google", "Google アカウント"
        )

        // These additional markers make detection work with layouts where the
        // header is not exposed but the account categories are.
        val hasAccountSection = pageText.containsAny(
            "Personal info", "Security and sign-in", "Wallet and subscriptions",
            "Personal information", "المعلومات الشخصية", "الأمان وتسجيل الدخول",
            "Google password", "Password Manager"
        )

        return hasGoogleAccount || hasAccountSection
    }

    private fun scrollGoogleAccountPage(root: AccessibilityNodeInfo) {
        if (scrollAttempts >= 12) return

        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)

        for (node in nodes) {
            if (node.isScrollable &&
                node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            ) {
                scrollAttempts++
                return
            }
        }
    }

    private fun descriptor(node: AccessibilityNodeInfo): String =
        listOf(node.text, node.hintText, node.contentDescription).joinToString(" ").lowercase()

    private fun String.containsAny(vararg values: String): Boolean = values.any { contains(it.lowercase()) }

    private fun editableNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        walk(root, out)
        return out.filter { it.isEditable && it.isEnabled }
    }

    private fun walk(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable) out.add(node)
        for (i in 0 until node.childCount) walk(node.getChild(i), out)
    }

    private fun clickByText(root: AccessibilityNodeInfo, labels: List<String>): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 900) return false
        val wanted = labels.map { it.lowercase() }
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, nodes)
        for (node in nodes) {
            if (wanted.any { descriptor(node).contains(it) }) {
                var p: AccessibilityNodeInfo? = node
                repeat(4) {
                    if (p?.isClickable == true && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        lastActionAt = now
                        return true
                    }
                    p = p?.parent
                }
            }
        }
        return false
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        out.add(node)
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun setText(node: AccessibilityNodeInfo, value: CharArray?): Boolean {
        if (value == null || value.isEmpty()) return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, String(value))
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun clearSecrets() {
        MainActivity.currentPassword?.fill('\u0000')
        MainActivity.newPassword?.fill('\u0000')
        MainActivity.currentPassword = null
        MainActivity.newPassword = null
        MainActivity.automationEnabled = false
    }

    override fun onInterrupt() {
        serviceConnected = false
        handler.removeCallbacksAndMessages(null)
        clearSecrets()
    }
}
