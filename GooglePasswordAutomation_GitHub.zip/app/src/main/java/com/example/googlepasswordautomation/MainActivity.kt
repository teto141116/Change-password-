package com.example.googlepasswordautomation

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object {
        @Volatile var currentPassword: CharArray? = null
        @Volatile var newPassword: CharArray? = null
        @Volatile var automationEnabled = false
        @Volatile var automationRunId = 0L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Google Password Automation"
            textSize = 24f
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "تغيير كلمة مرور حسابك تلقائيًا من خلال واجهة المتصفح"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }

        val power = Switch(this).apply {
            text = "ON / OFF"
            textSize = 18f
            isChecked = automationEnabled
        }

        val current = EditText(this).apply {
            hint = "كلمة المرور الحالية (عند طلب التحقق)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val newPass = EditText(this).apply {
            hint = "كلمة المرور الجديدة"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val confirm = EditText(this).apply {
            hint = "تأكيد كلمة المرور الجديدة"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val accessibility = Button(this).apply {
            text = "إعداد إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val start = Button(this).apply {
            text = "بدء التنفيذ"
            setOnClickListener {
                val np = newPass.text.toString()
                val cp = confirm.text.toString()
                if (!power.isChecked) {
                    subtitle.text = "التطبيق متوقف. فعّل ON أولًا."
                    return@setOnClickListener
                }
                if (np.isEmpty() || np != cp) {
                    subtitle.text = "كلمة المرور الجديدة والتأكيد غير متطابقين."
                    return@setOnClickListener
                }

                currentPassword?.fill('\u0000')
                newPassword?.fill('\u0000')
                currentPassword = current.text.toString().toCharArray()
                newPassword = np.toCharArray()
                automationRunId++
                automationEnabled = true
                subtitle.text = "جاهز. افتح أي متصفح واترك صفحة Google Account في المقدمة."
            }
        }

        power.setOnCheckedChangeListener { _, checked ->
            automationEnabled = checked
            if (!checked) {
                clearSecrets()
                subtitle.text = "التطبيق متوقف."
            } else {
                subtitle.text = "التطبيق مفعّل."
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(power)
        root.addView(current)
        root.addView(newPass)
        root.addView(confirm)
        root.addView(accessibility)
        root.addView(start)

        setContentView(root)
    }

    private fun clearSecrets() {
        currentPassword?.fill('\u0000')
        newPassword?.fill('\u0000')
        currentPassword = null
        newPassword = null
    }
}
