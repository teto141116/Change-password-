package com.example.googlepasswordautomation

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    companion object {
        @Volatile var pendingPassword: CharArray? = null
        @Volatile var automationEnabled = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Google Password Automation"
            textSize = 22f
        }

        val info = TextView(this).apply {
            text = "أدخل كلمة المرور الجديدة مرتين. البرنامج لا يقرأ كلمة المرور الحالية ولا يحفظ كلمة المرور الجديدة على الجهاز."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }

        val password = EditText(this).apply {
            hint = "كلمة المرور الجديدة"
            inputType = 0x81
        }

        val confirm = EditText(this).apply {
            hint = "تأكيد كلمة المرور"
            inputType = 0x81
        }

        val accessibility = Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val openGoogle = Button(this).apply {
            text = "فتح Google Account"
            setOnClickListener {
                val intent = packageManager.getLaunchIntentForPackage("com.android.chrome")
                if (intent != null) startActivity(intent)
            }
        }

        val start = Button(this).apply {
            text = "بدء التنفيذ"
            setOnClickListener {
                val p = password.text.toString()
                val c = confirm.text.toString()
                if (p.isEmpty() || p != c) {
                    info.text = "تأكد أن كلمتي المرور متطابقتان."
                    return@setOnClickListener
                }
                pendingPassword = p.toCharArray()
                automationEnabled = true
                info.text = "تم تجهيز التنفيذ. افتح Chrome واترك صفحة Google Account في المقدمة."
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(password)
        root.addView(confirm)
        root.addView(accessibility)
        root.addView(openGoogle)
        root.addView(start)

        setContentView(root)
    }

    override fun onDestroy() {
        // Clear UI copies; the service owns the in-memory copy while running.
        super.onDestroy()
    }
}
