package com.example.googlepasswordautomation

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.app.Activity

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var password: EditText
    private lateinit var confirm: EditText

    companion object {
        @Volatile var pendingPassword: CharArray? = null
        @Volatile var automationEnabled: Boolean = false
        @Volatile var submitAfterFormFound: Boolean = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        val title = TextView(this).apply {
            text = "Google Password Automation"
            textSize = 23f
        }

        val help = TextView(this).apply {
            text = "أدخل كلمة المرور الجديدة وتأكيدها. البرنامج لا يقرأ كلمة المرور الحالية ولا يحفظ كلمة المرور الجديدة على الجهاز."
            textSize = 16f
            setPadding(0, dp(14), 0, dp(14))
        }

        password = EditText(this).apply {
            hint = "كلمة المرور الجديدة"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        }

        confirm = EditText(this).apply {
            hint = "تأكيد كلمة المرور الجديدة"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val accessibility = Button(this).apply {
            text = "1 - تفعيل خدمة التحكم"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "افتح إعدادات إمكانية الوصول يدويًا", Toast.LENGTH_LONG).show()
                }
            }
        }

        val openBrowser = Button(this).apply {
            text = "2 - فتح المتصفح"
            setOnClickListener {
                val intent = packageManager.getLaunchIntentForPackage("com.android.chrome")
                    ?: Intent(Intent.ACTION_VIEW).apply {
                        data = android.net.Uri.parse("https://accounts.google.com/")
                    }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "لم يتم العثور على متصفح", Toast.LENGTH_LONG).show()
                }
            }
        }

        val start = Button(this).apply {
            text = "3 - بدء التنفيذ"
            setOnClickListener { startAutomation() }
        }

        status = TextView(this).apply {
            text = "الحالة: متوقف"
            textSize = 15f
            setPadding(0, dp(14), 0, 0)
        }

        root.addView(title)
        root.addView(help, lp())
        root.addView(password, lp())
        root.addView(confirm, lp())
        root.addView(accessibility, lp())
        root.addView(openBrowser, lp())
        root.addView(start, lp())
        root.addView(status, lp())

        setContentView(root)
    }

    private fun startAutomation() {
        val p = password.text?.toString() ?: ""
        val c = confirm.text?.toString() ?: ""
        if (p.isEmpty() || p != c) {
            status.text = "الحالة: كلمتا المرور غير متطابقتين."
            return
        }

        pendingPassword?.fill('\u0000')
        pendingPassword = p.toCharArray()
        automationEnabled = true

        password.text?.clear()
        confirm.text?.clear()
        status.text = "الحالة: جاهز. افتح أي متصفح وانتقل إلى صفحة تغيير كلمة المرور."
        Toast.makeText(this, "تم تجهيز التنفيذ", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        if (automationEnabled) {
            status.text = "الحالة: التنفيذ مفعل — افتح صفحة تغيير كلمة المرور في المتصفح."
        }
    }

    override fun onDestroy() {
        // Do not wipe the service's secret here; it may be actively using it.
        super.onDestroy()
    }

    private fun lp(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(8)
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
