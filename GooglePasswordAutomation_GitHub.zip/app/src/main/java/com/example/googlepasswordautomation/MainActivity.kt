package com.example.googlepasswordautomation

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

class MainActivity : Activity() {
    private enum class Step { IDLE, LOGIN_WAIT, FIND_PASSWORD, VERIFY_CURRENT, FILL_NEW, SUBMIT, DONE, STOPPED }

    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var power: Switch
    private lateinit var currentPassword: EditText
    private lateinit var newPassword: EditText
    private lateinit var confirmPassword: EditText

    private val handler = Handler(Looper.getMainLooper())
    private var step = Step.IDLE
    private var running = false
    private var currentSecret = ""
    private var newSecret = ""
    private var confirmSecret = ""
    private var lastActionAt = 0L
    private var detectedEmail = ""

    private val poller = object : Runnable {
        override fun run() {
            if (running && !isFinishing) {
                inspectAndAct()
                handler.postDelayed(this, 900L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        setupWebView()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 18)
        }

        val title = TextView(this).apply {
            text = "Google Password Automation"
            textSize = 23f
            setTextColor(Color.rgb(25, 25, 25))
            gravity = Gravity.CENTER
        }

        status = TextView(this).apply {
            text = "سجّل الدخول يدويًا داخل المتصفح، وبعدها التطبيق يكمل الخطوات تلقائيًا."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 16)
        }

        power = Switch(this).apply {
            text = "تشغيل الأتمتة"
            textSize = 17f
            isChecked = false
        }

        currentPassword = passwordField("كلمة المرور الحالية (لو Google طلبها)")
        newPassword = passwordField("كلمة المرور الجديدة")
        confirmPassword = passwordField("تأكيد كلمة المرور الجديدة")

        val start = Button(this).apply {
            text = "ابدأ"
            setOnClickListener { startAutomation() }
        }

        val openGoogle = Button(this).apply {
            text = "فتح Google Account"
            setOnClickListener { webView.loadUrl(GOOGLE_SECURITY_URL) }
        }

        val openLog = Button(this).apply {
            text = "فتح سجل تغيير الباسورد"
            setOnClickListener { shareLog() }
        }

        power.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                if (newPassword.text.toString() != confirmPassword.text.toString()) {
                    power.isChecked = false
                    setStatus("كلمة المرور الجديدة والتأكيد غير متطابقين.")
                } else {
                    setStatus("الأتمتة مفعّلة. سجّل الدخول يدويًا إذا لزم.")
                }
            } else {
                stopAutomation("تم إيقاف الأتمتة.")
            }
        }

        controls.addView(title)
        controls.addView(status)
        controls.addView(power)
        controls.addView(currentPassword, lp())
        controls.addView(newPassword, lp())
        controls.addView(confirmPassword, lp())
        controls.addView(start, lp())
        controls.addView(openGoogle, lp())
        controls.addView(openLog, lp())

        val scroll = ScrollView(this).apply { addView(controls) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun passwordField(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        textSize = 16f
        setSingleLine(true)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 8
    }

    private fun setupWebView() {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.settings.userAgentString = webView.settings.userAgentString + " GooglePasswordAutomation/2.0"

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                return !isAllowedGoogleUrl(url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (running) {
                    setStatus("صفحة Google اتحدثت… بفحص العناصر تلقائيًا.")
                    handler.postDelayed({ inspectAndAct() }, 500L)
                }
            }
        }

        webView.loadUrl(GOOGLE_SECURITY_URL)
    }

    private fun startAutomation() {
        val np = newPassword.text.toString()
        val cp = confirmPassword.text.toString()
        if (!power.isChecked) {
            setStatus("فعّل التشغيل أولًا.")
            return
        }
        if (np.isBlank() || np != cp) {
            setStatus("اكتب كلمة المرور الجديدة نفسها في الحقلين.")
            return
        }
        newSecret = np
        confirmSecret = cp
        currentSecret = currentPassword.text.toString()
        detectedEmail = ""
        running = true
        step = Step.LOGIN_WAIT
        lastActionAt = 0L
        setStatus("مستني تسجيل الدخول اليدوي… بعد الدخول التطبيق هيستلم الخطوات.")
        handler.removeCallbacks(poller)
        handler.post(poller)
    }

    private fun inspectAndAct() {
        if (!running || !isAllowedGoogleUrl(webView.url ?: "")) {
            if (running) setStatus("افتح صفحة Google Account داخل المتصفح الداخلي.")
            return
        }

        val script = """
            (function(){
              function norm(s){return (s||'').replace(/\\s+/g,' ').trim().toLowerCase();}
              function visible(e){
                if(!e) return false;
                var r=e.getBoundingClientRect();
                var cs=getComputedStyle(e);
                return r.width>0 && r.height>0 && cs.display!=='none' && cs.visibility!=='hidden';
              }
              function text(e){
                return norm((e.innerText||e.textContent||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||''));
              }
              function all(){return Array.from(document.querySelectorAll('a,button,[role="button"],input,textarea,[contenteditable="true"],div,span'));}
              var body=norm(document.body?document.body.innerText:'');
              var url=location.href;
              var signIn = /accounts\\.google\\.com\\/(v3\\/)?signin/i.test(url) || /sign in|تسجيل الدخول|connexion|iniciar sesión/.test(body);
              var captcha = /captcha|i'm not a robot|لست برنامج روبوت|verify you are human|تحقق أنك لست روبوت/.test(body);
              var mfa = /2-step verification|two-step verification|التحقق بخطوتين|رمز التحقق|verification code|security key/.test(body);
              var verify = /enter your password|confirm your password|verify it’s you|verify it's you|تحقق من هويتك|أدخل كلمة المرور|تأكيد كلمة المرور|password to continue/.test(body);
              var change = /change password|تغيير كلمة المرور|new password|كلمة المرور الجديدة|confirm new password|تأكيد كلمة المرور الجديدة/.test(body);
              var pw=Array.from(document.querySelectorAll('input[type="password"]')).filter(visible);
              var newInputs=pw.filter(function(e){var a=norm((e.name||'')+' '+(e.id||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.placeholder||'')+' '+(e.autocomplete||'')); return /new|confirm|newpassword|confirmation|password/.test(a);});
              var targets=all().filter(function(e){
                if(!visible(e)) return false;
                var t=text(e);
                return /google password|password|mot de passe|contraseña|كلمة المرور/.test(t);
              }).slice(0,30).map(function(e){return {tag:e.tagName,text:text(e).slice(0,180),href:e.href||'',id:e.id||'',name:e.getAttribute('name')||''};});
              var emailRe=/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              var emailMatches=(document.body?document.body.innerText:'').match(emailRe)||[];
              var emails=[]; emailMatches.forEach(function(e){if(emails.indexOf(e.toLowerCase())<0) emails.push(e.toLowerCase());});
              return JSON.stringify({url:url,signIn:signIn,captcha:captcha,mfa:mfa,verify:verify,change:change,passwords:pw.length,newInputs:newInputs.length,emails:emails,targets:targets});
            })();
        """.trimIndent()

        webView.evaluateJavascript(script) { raw ->
            try {
                val jsonText = raw.trim().removePrefix("\"").removeSuffix("\"").replace("\\\"", "\"").replace("\\n", "")
                val o = JSONObject(jsonText)
                val signIn = o.optBoolean("signIn")
                val captcha = o.optBoolean("captcha")
                val mfa = o.optBoolean("mfa")
                val verify = o.optBoolean("verify")
                val change = o.optBoolean("change")
                val passwords = o.optInt("passwords")
                val newInputs = o.optInt("newInputs")
                val emails = o.optJSONArray("emails")

                if (captcha || mfa) {
                    pauseForManual("Google طلب تحقق أمني. اعمل الخطوة دي يدويًا، والأتمتة متوقفة مؤقتًا.")
                    return@evaluateJavascript
                }
                if (signIn) {
                    step = Step.LOGIN_WAIT
                    setStatus("سجّل الدخول يدويًا داخل Google. أنا مستني بعد تسجيل الدخول.")
                    return@evaluateJavascript
                }

                if (emails != null && emails.length() > 0 && detectedEmail.isBlank()) {
                    detectedEmail = emails.optString(0).trim().lowercase()
                    if (detectedEmail.isNotBlank()) setStatus("الحساب المكتشف: $detectedEmail — مستني باقي الخطوات…")
                }

                when {
                    verify && currentSecret.isNotEmpty() -> fillCurrentPassword()
                    change && passwords >= 2 -> fillNewPasswords()
                    step == Step.SUBMIT -> clickChangePassword()
                    else -> findAndOpenPassword()
                }
            } catch (_: Exception) {
                // Web pages can change while loading; retry on the next poll.
            }
        }
    }

    private fun findAndOpenPassword() {
        if (cooldown()) return
        step = Step.FIND_PASSWORD
        setStatus("بدور على Google Password…")
        val js = """
            (function(){
              function norm(s){return (s||'').replace(/\\s+/g,' ').trim().toLowerCase();}
              function vis(e){var r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden';}
              var els=Array.from(document.querySelectorAll('a,button,[role="button"],div,span'));
              var hits=els.filter(function(e){
                if(!vis(e)) return false;
                var t=norm((e.innerText||e.textContent||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||''));
                return /google password/.test(t) || (/password|كلمة المرور/.test(t) && t.length<140);
              });
              if(hits.length){
                var e=hits[0];
                e.scrollIntoView({block:'center',behavior:'instant'});
                e.click();
                return 'clicked';
              }
              window.scrollBy(0, Math.max(350, window.innerHeight*0.65));
              return 'scroll';
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { result ->
            if (result.contains("clicked")) {
                setStatus("لقيت Google Password وفتحته…")
                lastActionAt = System.currentTimeMillis()
            }
        }
    }

    private fun fillCurrentPassword() {
        if (cooldown() || currentSecret.isEmpty()) return
        step = Step.VERIFY_CURRENT
        setStatus("Google طلب الباسورد الحالي… التطبيق بيدخله دلوقتي.")
        val escaped = JSONObject.quote(currentSecret)
        val js = """
            (function(){
              var p=Array.from(document.querySelectorAll('input[type="password"]')).find(function(e){
                var r=e.getBoundingClientRect(),c=getComputedStyle(e); return r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden';
              });
              if(!p) return 'no-input';
              var v=$escaped;
              var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
              setter.call(p,v);
              p.dispatchEvent(new Event('input',{bubbles:true}));
              p.dispatchEvent(new Event('change',{bubbles:true}));
              p.dispatchEvent(new Event('blur',{bubbles:true}));
              var bs=Array.from(document.querySelectorAll('button,[role="button"],input[type="submit"]')).filter(function(e){
                var r=e.getBoundingClientRect(); if(!(r.width>0&&r.height>0)) return false;
                var t=((e.innerText||e.value||e.getAttribute('aria-label')||'')+'').toLowerCase();
                return /next|continue|التالي|متابعة|submit/.test(t);
              });
              if(bs.length) bs[0].click();
              return 'filled';
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { result ->
            if (result.contains("filled")) {
                lastActionAt = System.currentTimeMillis()
                setStatus("تم إدخال الباسورد الحالي، مستني صفحة New password…")
            }
        }
    }

    private fun fillNewPasswords() {
        if (cooldown() || newSecret.isEmpty()) return
        step = Step.FILL_NEW
        setStatus("بدخل New password وConfirm new password…")
        val n = JSONObject.quote(newSecret)
        val c = JSONObject.quote(confirmSecret)
        val js = """
            (function(){
              function vis(e){var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';}
              var ps=Array.from(document.querySelectorAll('input[type="password"]')).filter(vis);
              if(ps.length<2) return 'not-ready';
              var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
              setter.call(ps[0],$n); ps[0].dispatchEvent(new Event('input',{bubbles:true})); ps[0].dispatchEvent(new Event('change',{bubbles:true}));
              setter.call(ps[1],$c); ps[1].dispatchEvent(new Event('input',{bubbles:true})); ps[1].dispatchEvent(new Event('change',{bubbles:true}));
              return 'filled';
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { result ->
            if (result.contains("filled")) {
                lastActionAt = System.currentTimeMillis()
                step = Step.SUBMIT
                setStatus("تم إدخال الباسوردين… بدور على Change password.")
            }
        }
    }

    private fun clickChangePassword() {
        if (cooldown()) return
        setStatus("بدوس Change password…")
        val js = """
            (function(){
              function vis(e){var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';}
              function norm(s){return (s||'').replace(/\\s+/g,' ').trim().toLowerCase();}
              var bs=Array.from(document.querySelectorAll('button,[role="button"],input[type="submit"]')).filter(vis);
              var hit=bs.find(function(e){var t=norm((e.innerText||e.value||e.getAttribute('aria-label')||'')+'');return /change password|تغيير كلمة المرور|changer le mot de passe|cambiar contraseña/.test(t);});
              if(!hit) return 'not-found';
              hit.scrollIntoView({block:'center',behavior:'instant'}); hit.click(); return 'clicked';
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { result ->
            if (result.contains("clicked")) {
                lastActionAt = System.currentTimeMillis()
                step = Step.DONE
                setStatus("تم الضغط على Change password. مستني تأكيد Google…")
                handler.postDelayed({ verifyDone() }, 1800L)
            }
        }
    }

    private fun verifyDone() {
        val js = """
            (function(){
              var t=((document.body&&document.body.innerText)||'').toLowerCase();
              var ok=/password changed|password updated|your password has been changed|password successfully changed|تم تغيير كلمة المرور|تم تحديث كلمة المرور|تم تغيير كلمة السر/.test(t);
              var emailRe=/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
              var es=((document.body&&document.body.innerText)||'').match(emailRe)||[];
              return JSON.stringify({ok:ok,emails:es});
            })();
        """.trimIndent()
        webView.evaluateJavascript(js) { raw ->
            try {
                val text = raw.trim().removePrefix("\"").removeSuffix("\"").replace("\\\"", "\"")
                val o = JSONObject(text)
                val ok = o.optBoolean("ok")
                val emails = o.optJSONArray("emails")
                if (detectedEmail.isBlank() && emails != null && emails.length() > 0) {
                    detectedEmail = emails.optString(0).trim().lowercase()
                }
                if (ok && detectedEmail.isNotBlank()) {
                    appendSuccessLog(detectedEmail)
                    setStatus("تم تغيير باسورد $detectedEmail بنجاح وتم تسجيل العملية في ملف Excel/CSV.")
                    stopAutomation(null)
                } else if (ok) {
                    setStatus("Google أكد نجاح تغيير الباسورد، لكن لم أتمكن من قراءة الإيميل؛ لم يتم تسجيل العملية.")
                    stopAutomation(null)
                } else {
                    setStatus("لم يظهر تأكيد نجاح واضح من Google؛ لم يتم تسجيل العملية.")
                    stopAutomation(null)
                }
            } catch (_: Exception) {
                setStatus("تعذر التحقق من رسالة النجاح؛ لم يتم تسجيل العملية.")
                stopAutomation(null)
            }
        }
    }

    private fun appendSuccessLog(email: String) {
        try {
            val resolver = contentResolver
            val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val projection = arrayOf(MediaStore._ID, MediaStore.DISPLAY_NAME)
            val selection = "${MediaStore.DISPLAY_NAME}=? AND ${MediaStore.RELATIVE_PATH}=?"
            val args = arrayOf(LOG_FILE_NAME, LOG_RELATIVE_PATH)
            var uri: Uri? = null
            resolver.query(collection, projection, selection, args, null)?.use { c ->
                if (c.moveToFirst()) {
                    uri = Uri.withAppendedPath(collection, c.getLong(c.getColumnIndexOrThrow(MediaStore._ID)).toString())
                }
            }
            var needsHeader = uri == null
            if (uri == null) {
                val values = android.content.ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, LOG_FILE_NAME)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, LOG_RELATIVE_PATH)
                }
                uri = resolver.insert(collection, values)
            }
            val target = uri ?: return
            if (!needsHeader) {
                resolver.openFileDescriptor(target, "r")?.use { pfd ->
                    needsHeader = pfd.statSize <= 0L
                }
            }
            resolver.openOutputStream(target, "wa")?.use { os ->
                OutputStreamWriter(os, StandardCharsets.UTF_8).use { w ->
                    if (needsHeader) w.append("email,changed_at,status\n")
                    val timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                    w.append(csv(email)).append(',').append(csv(timestamp)).append(",SUCCESS\n")
                }
            }
        } catch (_: Exception) {
            // Logging must never interrupt the password-change flow.
        }
    }

    private fun csv(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

    private fun shareLog() {
        try {
            val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val selection = "${MediaStore.DISPLAY_NAME}=? AND ${MediaStore.RELATIVE_PATH}=?"
            val args = arrayOf(LOG_FILE_NAME, LOG_RELATIVE_PATH)
            var uri: Uri? = null
            contentResolver.query(collection, arrayOf(MediaStore._ID), selection, args, null)?.use { c ->
                if (c.moveToFirst()) uri = Uri.withAppendedPath(collection, c.getLong(0).toString())
            }
            if (uri == null) {
                setStatus("لسه مفيش عمليات ناجحة مسجلة.")
                return
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "مشاركة سجل تغيير الباسورد"))
        } catch (_: Exception) {
            setStatus("ملف السجل موجود في مجلد Downloads/GooglePasswordAutomation.")
        }
    }

    private fun pauseForManual(message: String) {
        running = false
        step = Step.STOPPED
        setStatus(message)
    }

    private fun stopAutomation(message: String?) {
        running = false
        handler.removeCallbacks(poller)
        step = if (message == null) Step.DONE else Step.STOPPED
        currentSecret = ""
        newSecret = ""
        confirmSecret = ""
        detectedEmail = ""
        if (message != null) setStatus(message)
    }

    private fun cooldown(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 1400L) return true
        lastActionAt = now
        return false
    }

    private fun setStatus(message: String) {
        status.text = message
    }

    private fun isAllowedGoogleUrl(url: String): Boolean {
        return try {
            val u = android.net.Uri.parse(url)
            val host = u.host ?: return false
            u.scheme == "https" && (host == "accounts.google.com" || host.endsWith(".google.com"))
        } catch (_: Exception) { false }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        currentSecret = ""
        newSecret = ""
        confirmSecret = ""
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val GOOGLE_SECURITY_URL = "https://myaccount.google.com/security"
        private const val LOG_FILE_NAME = "GooglePasswordAutomation_Log.csv"
        private const val LOG_RELATIVE_PATH = "Download/GooglePasswordAutomation/"
    }
}
