# GooglePasswordAutomation

Android 16-ready, browser-independent Accessibility-based password form assistant.

## Important
- It does not read/extract the existing password.
- The new password exists only in memory during the run and is cleared afterward.
- It does not bypass CAPTCHA, 2-step verification, recovery checks, or other security challenges.
- It uses the active accessibility window rather than hard-coded screen coordinates.
- It is not restricted to Chrome; the service does not whitelist a browser package.

## Android
- compileSdk 36
- targetSdk 36
- Java/Kotlin JVM 17

## Use
1. Install APK.
2. Enable the service in Android Accessibility settings.
3. Enter the new password twice.
4. Tap Start.
5. Open the browser and navigate to the password-change page.
6. The service looks for semantic labels in the active accessibility tree and fills the new-password fields, then looks for a clear save/change action.

Browser/site accessibility trees differ. No accessibility automation can guarantee identical behavior on every browser or every website, so labels are handled as a multilingual semantic list and the service fails safely if it cannot identify the next step.
