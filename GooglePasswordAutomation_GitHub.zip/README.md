# Google Password Automation (Android)

A user-controlled Android Accessibility app that assists with changing a Google Account password in Chrome.

## Safety/design
- The app does **not** read or extract the existing password.
- The new password is kept only in memory while the automation is running.
- If Google presents CAPTCHA, 2-step verification, recovery prompts, or another security challenge, automation stops and the user completes it.
- The user must already be signed in to their own Google account in Chrome.

## How to use
1. Install the APK.
2. Open the app and enter the new password twice.
3. Enable the app under Android Accessibility settings.
4. Tap "Open Google Account".
5. Navigate to the Password page if needed.
6. Return to the app and tap "Start automation".
7. Keep Chrome in the foreground while it runs.

The automation uses Android's AccessibilityNodeInfo tree rather than fixed screen coordinates, so it is less dependent on exact button positions.

## GitHub Actions
The included workflow builds a debug APK and uploads it as an artifact.

> Google/Chrome UI can change. The accessibility labels used by the automation may need updating when Google's page structure changes.
