# GooglePasswordAutomation

Android app that keeps Google sign-in/manual security checks in the user's hands, then automates the password-change page inside its WebView.

## Success log
After Google visibly confirms that the password was changed, the app extracts the account email from the Google page and appends a row to:

`Downloads/GooglePasswordAutomation/GooglePasswordAutomation_Log.csv`

The CSV is Excel-compatible and contains `email`, `changed_at`, and `status`. It is written only after an explicit success message is detected; failed/uncertain attempts are not logged as successful.

The app includes a button to share the log file. Password values are not written to the log.
